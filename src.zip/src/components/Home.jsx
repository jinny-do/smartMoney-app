//Home.jsx
import React from 'react';

import LoginModal from '../Main/LoginModal';
export default function Home() {
    return (
        <div className="container py-4 text-center">
            <h1>똑똑한 가계부</h1>
        </div>
    );
}
